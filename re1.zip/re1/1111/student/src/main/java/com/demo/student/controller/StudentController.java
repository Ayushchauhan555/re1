package com.demo.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demo.student.model.Student;
import com.demo.student.service.StudentService;





@Controller
public class StudentController {
	@Autowired
	StudentService service;
	@RequestMapping("/home")
	public String home() { 
		System.out.println("inside home");
		return "home";
	}
	
	 @RequestMapping(value="/addStu", method=RequestMethod.GET) 
	  public  ModelAndView loadAddStudent() {
	  
	 
		  ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("addStu"); mav.addObject("Stu", new Student()); 
		  return mav; 
	  }
	 
	 @RequestMapping(value="/addStu", method=RequestMethod.POST)
		public ModelAndView addStudent(@ModelAttribute("Stu") Student Stu) {
			
			service.addStudent(Stu);
			ModelAndView mav = new ModelAndView("addStu");
			String message = "Student Added Successfully with Student id "+Stu.getId();
			mav.addObject("successMessage", message);
			return mav;
	 }
	 
	 @RequestMapping(value="/dispAllStu", method=RequestMethod.GET)
		public ModelAndView getStudent() {
			List<Student> list = service.getStudents();
			ModelAndView mav = new ModelAndView("dispAllStu");
			if(list.isEmpty()) {
				mav.addObject("errorMessage", "Student details not found");			
			}
			else {
				mav.addObject("StuList",list);			
			}
			
			return mav;
		}
	 @RequestMapping(value="/dispStuById", method=RequestMethod.GET)
		public ModelAndView loadGetStudentById() {			
			ModelAndView mav = new ModelAndView("dispStuById");		
			return mav;
		}
		
		@RequestMapping(value="/dispStuById", method=RequestMethod.POST)
		public ModelAndView getStduentById(@RequestParam Integer id) {
			Student s = service.findStudent(id);
			System.out.println("found = "+s);
			ModelAndView mav = new ModelAndView("dispStuById");	
			if(s!=null) {
				mav.addObject("Stu", s);
			}
			else
				mav.addObject("errorMessage","Student details not found for the given Student id");
			
			return mav;
		}
		
		
	 
	 
}
