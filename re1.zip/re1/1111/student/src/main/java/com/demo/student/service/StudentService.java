package com.demo.student.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.student.model.Student;
import com.demo.student.repository.StudentRepository;




@Service
public class StudentService {
	
	@Autowired
	StudentRepository rep;
	
	@Transactional
	public void addStudent(Student stud)
	{
		rep.saveAndFlush(stud);
    }
	
	public Student findStudent(int id){
		Optional<Student> opt=rep.findById(id);
		if(opt.isPresent()) 
			return opt.get();	
		return null;
	}
	
	public List<Student> getStudents(){
		return rep.findAll();
	}
	
}
