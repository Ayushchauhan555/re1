create database datadb;
use datadb;
create table Orders(id int(5) auto_increment primary key,price double, quantity int(5), amount double,charges double);