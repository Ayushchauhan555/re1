package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bean.Order;
import com.capgemini.exception.OrderException;
import com.capgemini.service.OrderService;

@RestController/*Controller*/
public class OrderController {
	@Autowired
	OrderService service;
	
	/*
	 * Mapping		: /orders
	 * RequestMethod: GET
	 * Description	: Shows all the orders in the DataBase
	 * */
	@RequestMapping("/orders")
	public List<Order> viewAllOrders() throws OrderException
	{
		return service.viewAllOrders();
	}
	
	/*
	 * Mapping		: /addOrder
	 * RequestMethod: POST
	 * Description	: Add an order into the DataBase
	 * */
	@RequestMapping(value="/addOrder",method=RequestMethod.POST)
	public List<Order> createOrder(@RequestBody Order order) throws OrderException
	{
		return service.createOrder(order);
	}
	
	/*
	 * Mapping		: /updateOrder/{id}
	 * RequestMethod: PUT
	 * Description	: Update an order in the DataBase using its id
	 * */
	@PutMapping("/updateOrder/{id}")
	public List<Order> updateOrder(@PathVariable int id,@RequestBody Order order) throws OrderException
	{
		return service.updateOrder(id, order);
	}
	
	/*
	 * Mapping		: /orders/{min}/{max}
	 * RequestMethod: GET
	 * Description	: Shows list of orders in the given quantity range
	 * */
	@RequestMapping("/orders/{min}/{max}")
	public List<Order> viewOrderRange(@PathVariable int min,@PathVariable int max) throws OrderException
	{
		return service.viewOrderRange(min, max);
	}
	
	/*
	 * Mapping		: /orders/{amt}
	 * RequestMethod: GET
	 * Description	: Shows list of orders greater than the given amount
	 * */
	@RequestMapping("/orders/{amt}")
	public List<Order> viewOrderGreater(@PathVariable double amt) throws OrderException
	{
		return service.viewOrderGreater(amt);
	}
}
