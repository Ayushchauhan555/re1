package com.stock.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stock.bean.Stock;
import com.stock.exception.StockException;
import com.stock.service.StockService;

@RestController
public class StockController {
	@Autowired
	StockService stockService;
	
	@GetMapping("/stocks")
	public List <Stock> viewAllStock() throws StockException
	{
		return stockService.viewAllStock();
	}
	@RequestMapping(value="/stocks", method=RequestMethod.POST)
	public List<Stock> createStock(@RequestBody Stock pro) throws StockException{
		return stockService.createStock(pro);
			}
	
	@DeleteMapping("/stocks/{id}")	
	public ResponseEntity<String> deleteStock(@PathVariable Integer id) throws StockException {
		stockService.deleteStock(id);
	return new ResponseEntity<String> ("stock with the id "+id+" deleted",HttpStatus.OK);
	}
	
	@RequestMapping("/stocks/{id}")
	public Stock findSingleStock(@PathVariable Integer id) throws StockException{
	return stockService.findSingleStock(id);
    }
	
	
	@PutMapping("/stocks/{id}")
	public List <Stock> updateStock(@PathVariable Integer id, @RequestBody Stock pro) throws StockException{
		return stockService.updateStock(id, pro);
	}
	
}