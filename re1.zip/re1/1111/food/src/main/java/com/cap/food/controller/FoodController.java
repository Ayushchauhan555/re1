package com.cap.food.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cap.food.bean.Food;
import com.cap.food.exception.FoodException;
import com.cap.food.service.FoodService;



@RestController/*Controller*/
public class FoodController {
	@Autowired
	FoodService service;
	
	/*
	 * Mapping		: /orders
	 * RequestMethod: GET
	 * Description	: Shows all the orders in the DataBase


	/*
	 * Mapping		: /orders
	 * RequestMethod: GET
	 * Description	: Shows all the orders in the DataBase
	 * */
	

	/*
	 * Mapping		: /orders
	 * RequestMethod: GET
	 * Description	: Shows all the orders in the DataBase
	 * */
	@RequestMapping("/foods")
	public List<Food> viewAllFoods() throws FoodException
	{
		return service.viewAllFoods();
	}
	
	/*
	 * Mapping		: /addOrder
	 * RequestMethod: POST
	 * Description	: Add an order into the DataBase
	 * */

	/*
	 * Mapping		: /addOrder
	 * RequestMethod: POST
	 * Description	: Add an order into the DataBase
	 * */
	
	/*
	 * Mapping		: /addOrder
	 * RequestMethod: POST
	 * Description	: Add an order into the DataBase
	 * */
	@RequestMapping(value="/addFood",method=RequestMethod.POST)
	public List<Food> createFood(@RequestBody Food food) throws FoodException
	{
		return service.createFood(food);
	}
	
	/*
	 * Mapping		: /updateOrder/{id}
	 * RequestMethod: PUT
	 * Description	: Update an order in the DataBase using its id
	 * */
	

	/*
	 * Mapping		: /updateOrder/{id}
	 * RequestMethod: PUT
	 * Description	: Update an order in the DataBase using its id
	 * */
	@PutMapping("/updateFood/{id}")
	public List<Food> updateFood(@PathVariable int id,@RequestBody Food food) throws FoodException
	{
		return service.updateFood(id, food);
	}
	
	/*
	 * Mapping		: /orders/{min}/{max}
	 * RequestMethod: GET
	 * Description	: Shows list of orders in the given quantity range
	 * */

	/*
	 * Mapping		: /orders/{min}/{max}
	 * RequestMethod: GET
	 * Description	: Shows list of orders in the given quantity range
	 * */
	@RequestMapping("/foods/{min}/{max}")
	public List<Food> viewFoodRange(@PathVariable int min,@PathVariable int max) throws FoodException
	{
		return service.viewFoodRange(min, max);
	}
	
	/*
	 * Mapping		: /orders/{amt}
	 * RequestMethod: GET
	 * Description	: Shows list of orders greater than the given amount
	 * */
	
	/*
	 * Mapping		: /orders/{amt}
	 * RequestMethod: GET
	 * Description	: Shows list of orders greater than the given amount
	 * */
	@RequestMapping("/foods/{amt}")
	public List<Food> viewFoodGreater(@PathVariable double amt) throws FoodException
	{
		return service.viewFoodGreater(amt);
	}
}
