package com.cap.food.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.food.bean.Food;
import com.cap.food.dao.FoodDao;
import com.cap.food.exception.FoodException;


@Service/*Service Layer*/
public class FoodServiceImpl implements FoodService {
	@Autowired/*AutoWiring dao Layer*/
	FoodDao dao;
	
	/*
	 * Method Name	:	createOrder
	 * Arguments	:	Order
	 * Return Type	:	List<Order>
	 * Description	:	Returns a list of database after invoking
	 * 					the dao layer to create an entry
	 * */
	
	/*
	 * Method Name	:	createOrder
	 * Arguments	:	Order
	 * Return Type	:	List<Order>
	 * Description	:	Returns a list of database after invoking
	 * 					the dao layer to create an entry
	 * */
	@Override
	public List<Food> createFood(Food food) throws FoodException {
		// TODO Auto-generated method stub
		try {
			food=generatefields(food);
			dao.save(food);
			return dao.findAll();
		}
		catch(Exception e) {
			throw new FoodException(e.getMessage());
		}
	}
	
	/*
	 * Method Name	:	updateOrder
	 * Arguments	:	Integer, Order
	 * Return Type	:	List<Order>
	 * Description	:	Updates the entry in the given id with the object
	 * */
	

	/*
	 * Method Name	:	updateOrder
	 * Arguments	:	Integer, Order
	 * Return Type	:	List<Order>
	 * Description	:	Updates the entry in the given id with the object
	 * */
	@Override
	public List<Food> updateFood(int id,Food food) throws FoodException {
		// TODO Auto-generated method stub
		try {
			Optional<Food> optional = dao.findById(id);
			food=generatefields(food);
			if(optional.isPresent())
			{
				Food o=new Food();
				o.setId(id);
				o.setName(food.getName());
				o.setQuantity(food.getQuantity());
				o.setPrice(food.getPrice());
				o.setAmount(food.getAmount());
				o.setCharges(food.getCharges());
				dao.save(o);
				return dao.findAll();
			}
			else
			{
				throw new FoodException("Order with Id="+id+" does not exist");	
			}
		}
		catch(Exception e)
		{
			throw new FoodException(e.getMessage());
		}
	}
	
	/*
	 * Method Name	:	viewAllOrders
	 * Return Type	:	List<Order>
	 * Description	:	Returns list of the objects after invoking dao layer
	 * */

	/*
	 * Method Name	:	viewAllOrders
	 * Return Type	:	List<Order>
	 * Description	:	Returns list of the objects after invoking dao layer
	 * */
	@Override
	public List<Food> viewAllFoods() throws FoodException {
		// TODO Auto-generated method stub
		try
		{
			return dao.findAll();
		}
		catch(Exception e)
		{
			throw new FoodException(e.getMessage());
		}
	}
	
	/*
	 * Method Name	:	viewOrderRange
	 * Arguments	:	Integers
	 * Return Type	:	List<Order>
	 * Description	:	Returns list of orders between the given range
	 * 					by invoking the dao layer
	 * */

	/*
	 * Method Name	:	viewOrderRange
	 * Arguments	:	Integers
	 * Return Type	:	List<Order>
	 * Description	:	Returns list of orders between the given range
	 * 					by invoking the dao layer
	 * */
	@Override
	public List<Food> viewFoodRange(int min, int max) throws FoodException {
		// TODO Auto-generated method stub
		try {
			return dao.viewFoodRange(min, max);
		}
		catch(Exception e)
		{
			throw new FoodException(e.getMessage());
		}
	}
	
	/*
	 * Method Name	:	viewOrderGreater
	 * Arguments	:	Double
	 * Return Type	:	List<Order>
	 * Description	:	Return the list of orders with amount greater than
	 * 					the given amount
	 * */

	/*
	 * Method Name	:	viewOrderGreater
	 * Arguments	:	Double
	 * Return Type	:	List<Order>
	 * Description	:	Return the list of orders with amount greater than
	 * 					the given amount
	 * */
	@Override
	public List<Food> viewFoodGreater(double amount) throws FoodException {
		// TODO Auto-generated method stub
		try {
			return dao.viewFoodGreater(amount);
		}
		catch(Exception e)
		{
			throw new FoodException(e.getMessage());
		}
	}
	
	/*
	 * Method Name	:	generatefields
	 * Arguments	:	Order
	 * Return Type	:	Order
	 * Description	:	Generates the amount and charges
	 * */
	public Food generatefields(Food food)
	{
		int quantity=food.getQuantity();
		double price=food.getPrice();
		double amount=quantity*price*75;
		double charges=(amount*(1.25))/100;
		food.setAmount(amount);
		food.setCharges(charges);
		return food;
	}

}
