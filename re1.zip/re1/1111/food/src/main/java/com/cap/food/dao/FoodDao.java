package com.cap.food.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cap.food.bean.Food;


@Repository/*Repository Layer*/
public interface FoodDao extends JpaRepository<Food, Integer>{
	

	@Query("from Food food where food.quantity between :min and :max")
	List<Food> viewFoodRange(@Param("min")int min,@Param("max")int max);

	
	
	

	@Query("from Food food where food.amount > :amt")
	List<Food> viewFoodGreater(@Param("amt")double amt);
}
