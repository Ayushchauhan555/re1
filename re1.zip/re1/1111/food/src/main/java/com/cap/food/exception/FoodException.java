package com.cap.food.exception;

/*Exception class*/
public class FoodException extends Exception {
	public FoodException()
	{
		super();
	}
	public FoodException(String msg)
	{
		super(msg);
	}
}
