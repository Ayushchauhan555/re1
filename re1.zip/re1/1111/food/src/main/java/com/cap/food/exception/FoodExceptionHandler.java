package com.cap.food.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice/*Excepiton Handler*/
public class FoodExceptionHandler {
	@ExceptionHandler(FoodException.class)
	public ResponseEntity <String> handleException(Exception ex)
	{
		return new ResponseEntity <String> ("Error Occurred : "+ex.getMessage(), HttpStatus.CONFLICT);
	}
}
