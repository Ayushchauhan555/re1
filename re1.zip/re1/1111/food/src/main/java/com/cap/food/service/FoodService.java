package com.cap.food.service;

import java.util.List;

import com.cap.food.bean.Food;
import com.cap.food.exception.FoodException;


/*Service Layer*/
public interface FoodService {

	public List<Food> createFood(Food food) throws FoodException;
	
	public List<Food> updateFood(int id,Food food) throws FoodException;

	public List<Food> viewAllFoods() throws FoodException;

	public List<Food> viewFoodRange(int min, int max) throws FoodException;

	public List<Food> viewFoodGreater(double amount) throws FoodException;
}
