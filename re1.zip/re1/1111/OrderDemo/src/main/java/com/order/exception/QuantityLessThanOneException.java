package com.order.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_GATEWAY)
public class QuantityLessThanOneException extends Exception {

		public QuantityLessThanOneException() {
			super();
		}
		public QuantityLessThanOneException(String errors) {
			super(errors);
		}

	
}
