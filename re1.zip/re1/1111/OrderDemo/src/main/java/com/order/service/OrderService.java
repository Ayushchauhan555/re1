package com.order.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.order.entity.Order;
import com.order.exception.OrderrNotFoundException;
import com.order.exception.QuantityLessThanOneException;
import com.order.repository.OrderRepository;


@Service
@Transactional
public class OrderService {
	
	@Autowired
	OrderRepository orderRepository;
	

	public Order createOrder(Integer quantity, Double price) throws QuantityLessThanOneException {
		Order entity =  new Order();
			int inr = 75;
			double amountInInr = price * inr * quantity;
			double charges = (1.25/100 )* amountInInr;
			entity.setPrice(price);
			entity.setQuantity(checkQuantity(quantity));
			entity.setAmount(amountInInr);
			entity.setCharges(charges);
			orderRepository.saveAndFlush(entity);
			System.out.println("Order Added successfully");
			return entity;
	}


	public List<Order> viewAllOrders() {
		List<Order> orderList= orderRepository.findAll();
		if(orderList.isEmpty() || orderList.size()==0) {
			throw new OrderrNotFoundException("Order details does not exist");
		}
		
		List<Order>list = new ArrayList();
		for (Order entity : orderList) {
			Order order = new Order();
			order.setOrderId(entity.getOrderId());
			order.setPrice(entity.getPrice());
			order.setQuantity(entity.getQuantity());
			order.setCharges(entity.getCharges());
			order.setAmount(entity.getAmount());
			list.add(order);
		}
		return list;
	}

	

	public String updateOrder(int orderId, Order order) {
		Optional<Order> opt=orderRepository.findById(orderId);
		if(opt.isPresent())
		 {
			Order entity=opt.get();
			entity.setPrice(order.getPrice());
			entity.setAmount(order.getAmount());
			entity.setCharges(order.getCharges());
			entity.setQuantity(order.getQuantity());
			orderRepository.save(entity);
		 } 
		else {
			throw new OrderrNotFoundException(orderId + " does not exist");
		}
		return "Order details updated successfully";
	}

	 public List<Order> findByQuantity(int quantity1,int quantity2) {
        List<Order> orders = orderRepository.findByQuantity(quantity1,quantity2);
        System.out.println(orders);
        return orders;
    }

	public List<Order> viewOrderByAmount(double amount) {
			List<Order> orders = (List<Order>) orderRepository.viewOrderByAmount(amount);
	        System.out.println(orders);
	        return orders;
	}	
	
	
	
	///////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////Validation////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////
	
	private int checkQuantity(Integer quantity) throws QuantityLessThanOneException {
		if(quantity<1) {
			throw new QuantityLessThanOneException("Quantity should not less than 1");
		}
		else {
			return quantity;
		}
	}

}
