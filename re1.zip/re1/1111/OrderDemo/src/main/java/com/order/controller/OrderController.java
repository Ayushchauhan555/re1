package com.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.order.entity.Order;
import com.order.exception.QuantityLessThanOneException;
import com.order.service.OrderService;



@RestController
public class OrderController {
	@Autowired
	OrderService orderService;
	
	@PostMapping(value="/addOrder")
	public ResponseEntity<Order> createOrder(@RequestBody Order order) throws QuantityLessThanOneException {
		Double  price = order .getPrice();
		Integer quantity = order.getQuantity();
		Order response = orderService.createOrder(quantity,price);
		//return new ResponseEntity<String>(response, HttpStatus.OK);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping(value="/viewAllOrders")
	public ResponseEntity<List<Order>> getAllOrders(){ 
		List<Order> orderList= orderService.viewAllOrders();
		return ResponseEntity.ok(orderList);
	}
	
	@PutMapping(value = "/updateOrder/{orderId}")
	public String updateEmployee(@PathVariable("orderId") int orderId, @RequestBody Order order){
		return orderService.updateOrder(orderId, order);
	}
	
	@GetMapping(value="/getOrder/{quantity1}/{quantity2}")
	public ResponseEntity<List<Order>> findByQuantity(@PathVariable int quantity1,@PathVariable int quantity2){ 
		List<Order> order=  orderService.findByQuantity(quantity1,quantity2);
		return ResponseEntity.ok(order);
	}

	@GetMapping(value="/getOrderByAmount/{amount}")
	public ResponseEntity<List<Order>> viewOrderByAmount(@PathVariable("amount") double amount){ 
		List<Order> order=  orderService.viewOrderByAmount(amount);
		return ResponseEntity.ok(order);
	}

}
