package com.training.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.dao.TraineeDao;
import com.training.model.Admin;
import com.training.model.Trainee;

@Service
public class TraineeService {
	@Autowired
	TraineeDao repository;
	public boolean validateAdmin(Admin admin) {
		if(admin.getUsername().equals("admin") && admin.getPassword().equals("admin123")) {
			return true;
		}
		else{
			return false;
		}
	}

	@Transactional
	public void addTrainee(Trainee trainee) {
		repository.saveAndFlush(trainee);
	}


	public Trainee getTrainee(int tid) {
		Optional<Trainee> opt=repository.findById(tid);
		if(opt.isPresent()) 
			return opt.get();	
		return null;
	}

	public boolean deleteTrainee(Integer traineeId) {
		Optional<Trainee> opt=repository.findById(traineeId);
		if(opt.isPresent())
		 {
			Trainee t=opt.get();
			repository.delete(t);
			return true;
			
		 }
		else 
		{
			System.out.println("Not found employee");
			return false;
		} 
	}



}
